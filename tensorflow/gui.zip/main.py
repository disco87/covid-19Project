# -*- coding: utf-8 -*-

from kivy.app import App
from kivy.uix.screenmanager import ScreenManager, Screen
from kivy.properties import BooleanProperty, ListProperty, StringProperty, ObjectProperty
from kivy.core.window import Window
import func_module as fm
from kivy.clock import Clock
from kivy.graphics.texture import Texture
from kivy.uix.image import Image
from kivy.uix.popup import Popup
from kivy.uix.recycleview import RecycleView

class ScreenMain(Screen,Image):#main page
    # pass
    def __init__(self, **kw):
        super(ScreenMain,self).__init__(**kw)
        self.fps = 24 #카메라 프레임 설정
        self.func = fm.Func_Class()
        Clock.schedule_interval(self.update,1.0/self.fps)
                
       
    def update(self,dt):
        buf = self.func.live_show()        
        self.texture = buf

    def song_popup(self):#노래 리스트 팝업
        print (fm.Func_Class.file_list)
        song_pop = SongPopup()
        song_pop.open()    
        
class ScreenOne(Screen):#관리자 페이지
    pass
class SongPopup(Popup):
    rv = ObjectProperty()
    pass
class Rv(RecycleView):
    def __init__(self, **kwargs):
        super(Rv, self).__init__(**kwargs)
        self.data = [{'text':str(i)} for i in fm.Func_Class.file_list]#data 를 만들 때 튜플 형식으로 만들어야 한다.(key:vlaue)

class Manager(ScreenManager):#스크린 전환을 위한 screen manager 
    screen_main_id = ObjectProperty()#각 스크린의 객체를 받기 위한 임시 오브젝트를 생성하여
    screen_one_id = ObjectProperty()#screenmain.kv에서 각 화면의 클래스를 할당해준다.

class SwitchApp(App):
    def build(self):#kivy를 상속 받아 실행 했을 시 가장 처음에 실해후 실행 안함(init과 동일한 기능) - life cycle참조
        fm.Func_Class.cam_init()
        fm.Func_Class.song_init()
        return Manager()#manager 클래스를 실행하여 반환    

if __name__ == '__main__':
    SwitchApp().run()
    