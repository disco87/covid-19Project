 #-*- coding: utf-8 -*- 
import PIL
from PIL import Image,ImageTk
import cv2
import os
from pygame import mixer
from kivy.graphics.texture import Texture

class Func_Class:
#https://github.com/opencv/opencv/tree/master/data/haarcascades xml페이지 - 라이브러리  
###카메라 관련 처리######################################    
    def cam_init(cls):#카메라 관련 초기화
        Func_Class.cap = cv2.VideoCapture(0)
        Func_Class.cap.set(cv2.CAP_PROP_FRAME_WIDTH, 450)
        Func_Class.cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 450)
    cam_init = classmethod(cam_init)     
    def off_show(cls):
        cv2.VideoCapture(0, cv2.CAP_DSHOW)
    off_show = classmethod(off_show)
    #카메라 컬러 출력 
    def live_show(self):              
        ret, frame = Func_Class.cap.read()
        if ret:            
            frame = cv2.flip(frame, 1)
            buf = frame.tostring()
            image_texture = Texture.create(size=(frame.shape[1], frame.shape[0]), colorfmt='bgr')
            #print(frame.shape[0])
            image_texture.blit_buffer(buf, colorfmt='bgr', bufferfmt='ubyte')
            # cv2image = cv2.cvtColor(frame, cv2.COLOR_BGR2RGBA)#color 형태 변경
            # img = PIL.Image.fromarray(cv2image)
            # imgtk = ImageTk.PhotoImage(image=img)
            
            return image_texture
    # 카메라 이진화 변경
    def live_black(self): 
        _, frame = Func_Class.cap.read()            
        frame = cv2.flip(frame, 1)
        gray = cv2.cvtColor(frame, cv2.COLOR_RGB2GRAY)#gray test
        ret, dst = cv2.threshold(gray, 100, 255, cv2.THRESH_BINARY)#gray test
        img = PIL.Image.fromarray(dst)#gray test
        imgtk = ImageTk.PhotoImage(image=img)
        return imgtk
###노래 관련############################################
    #노래 관련 초기화 
    def song_init(cls): 
        Func_Class.path_dir ='C:/Users/w/Documents/python/mp3' #mp3 root 위치 변수
        Func_Class.file_list = os.listdir(Func_Class.path_dir) #폴더내의 파일 list 생성
        Func_Class.file_list.sort() #리스트내 이름정렬
        mixer.init()#mixer init
        
    song_init = classmethod(song_init)
    #노래 재생
    def song_play(self,path):          
        mixer.music.load(Func_Class.path_dir + path)#파일 load
        mixer.music.play()#mp3 play
    def song_stop(self):
        mixer.music.stop()
    
